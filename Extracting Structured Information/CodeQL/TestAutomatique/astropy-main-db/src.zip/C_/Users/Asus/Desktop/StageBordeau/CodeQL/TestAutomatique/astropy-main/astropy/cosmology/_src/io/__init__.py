"""Astropy Cosmology IO. **NOT public API**.

The public API is provided by :mod:`astropy.cosmology.io`.
"""
# Licensed under a 3-clause BSD style license - see LICENSE.rst
