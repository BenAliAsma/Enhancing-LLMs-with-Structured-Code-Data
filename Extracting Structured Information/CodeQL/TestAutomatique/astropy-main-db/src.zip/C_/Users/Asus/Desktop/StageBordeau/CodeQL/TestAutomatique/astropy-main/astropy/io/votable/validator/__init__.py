# Licensed under a 3-clause BSD style license - see LICENSE.rst
from . import main
from .main import make_validation_report

__doc__ = main.__doc__
del main
